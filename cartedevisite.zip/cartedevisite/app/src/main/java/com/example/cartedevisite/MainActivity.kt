package com.example.cartedevisite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cartedevisite.ui.theme.CarteDeVisiteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CarteDeVisiteTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ProfessionalCard(
                        name = "Yeo Nidjo Kalifa",
                        title = "Directeur de NumCenterSolution",
                        phone = "+225 0797676545",
                        email = "kalifayeo11@gmail.com",
                        location = "Abidjan, Plateau",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun ProfessionalCard(
    name: String,
    title: String,
    phone: String,
    email: String,
    location: String,
    modifier: Modifier = Modifier
) {
    // Structure générale de la carte
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(color = Color(0xFFEEEEEE), shape = RoundedCornerShape(16.dp)), // Couleur de fond gris clair
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Section d'image avec logo
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier
                .size(120.dp)
               // .clip(CircleShape)
                .background(Color.White, shape = CircleShape)
                .padding(4.dp),
            contentScale = ContentScale.Crop
        )

        // Nom et Titre
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp
            ),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Medium,
                fontSize = 20.sp
            ),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )


        Spacer(modifier = Modifier.height(24.dp))
        ContactInfo(R.drawable.contact, phone)
        ContactInfo(R.drawable.mail, email)
        ContactInfo(R.drawable.localisation, location)
    }
}

@Composable
fun ContactInfo(iconId: Int, info: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = iconId),
            contentDescription = null,
            modifier = Modifier.size(20.dp)
                .padding(end = 8.dp)
        )
        Text(
            text = info,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            ),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@Preview(showBackground = true, widthDp = 600, heightDp = 400)
@Composable
fun ProfessionalCardPreview() {
    CarteDeVisiteTheme {
        ProfessionalCard(
            name = "Yeo Nidjo Kalifa",
            title = "Directeur de NumCenterSolution",
            phone = "+225 0797676545",
            email = "kalifayeo11@gmail.com",
            location = "Abidjan, Plateau"
        )
    }
}
